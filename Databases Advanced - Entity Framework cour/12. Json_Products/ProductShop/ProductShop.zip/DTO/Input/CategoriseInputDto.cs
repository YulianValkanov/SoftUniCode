﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO.Input
{
    public class CategoriseInputDto
    {
        public string Name { get; set; }

    }
}
