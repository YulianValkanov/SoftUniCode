﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTO.Output
{
    public class ProductsOutputDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Seller { get; set; }




       

    }
}
