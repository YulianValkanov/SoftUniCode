﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-8164Q69;Database=TeisterMask;Trusted_Connection=True";
    }
}
